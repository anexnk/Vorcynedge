exports.handler = async function () {
  try {
    const response = await fetch("https://api.football-data.org/v4/competitions/PL/matches", {
      headers: {
        "X-Auth-Token": process.env.FOOTBALL_DATA_TOKEN
      }
    });

    const data = await response.json();

    return {
      statusCode: response.status,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Unable to fetch football data"
      })
    };
  }
};